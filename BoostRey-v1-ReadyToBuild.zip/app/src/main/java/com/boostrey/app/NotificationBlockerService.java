package com.boostrey.app;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class NotificationBlockerService extends NotificationListenerService {
    public static boolean blocking = false;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (blocking) {
            try { cancelNotification(sbn.getKey()); } catch (Exception ignored) {}
        }
    }
}
