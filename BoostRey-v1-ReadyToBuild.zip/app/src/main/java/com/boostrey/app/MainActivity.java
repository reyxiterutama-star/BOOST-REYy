package com.boostrey.app;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status;
    boolean boostOn=false, crossOn=false, blockOn=false;
    WindowManager wm;
    TextView crosshair;

    int bg=Color.rgb(16,18,20), card=Color.rgb(29,33,37), green=Color.rgb(0,200,83);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    TextView text(String s, float size) {
        TextView t=new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(22,16,22,16);
        return t;
    }

    Button button(String s) {
        Button b=new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setAllCaps(false);
        GradientDrawable g=new GradientDrawable(); g.setColor(card); g.setCornerRadius(18);
        b.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,70);
        p.setMargins(16,7,16,7); b.setLayoutParams(p);
        return b;
    }

    void build() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0,14,0,10); root.setBackgroundColor(bg);

        TextView title=text("BOOST REY",30);
        title.setTextColor(green); root.addView(title);
        TextView sub=text("Game utility • Non-root",14); sub.setTextColor(Color.LTGRAY); root.addView(sub);

        status=text("Status: siap",15); status.setTextColor(Color.LTGRAY); root.addView(status);

        Button boost=button("⚡  BOOST MODE  •  OFF");
        boost.setOnClickListener(v -> {
            boostOn=!boostOn;
            boost.setText(boostOn ? "⚡  BOOST MODE  •  ON" : "⚡  BOOST MODE  •  OFF");
            status.setText(boostOn ? "Status: Boost aktif" : "Status: siap");
            Toast.makeText(this, boostOn ? "Mode Boost aktif." : "Mode Boost dimatikan.", Toast.LENGTH_SHORT).show();
        });
        root.addView(boost);

        Button cross=button("🎯  CROSSHAIR  •  OFF");
        cross.setOnClickListener(v -> {
            crossOn=!crossOn;
            cross.setText(crossOn ? "🎯  CROSSHAIR  •  ON" : "🎯  CROSSHAIR  •  OFF");
            if(crossOn) showCrosshair(); else hideCrosshair();
        });
        root.addView(cross);

        Button notif=button("🔕  BLOKIR NOTIFIKASI  •  OFF");
        notif.setOnClickListener(v -> {
            if(!isNotificationAccessGranted()) {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                Toast.makeText(this,"Aktifkan akses notifikasi untuk Boost Rey, lalu kembali ke aplikasi.",Toast.LENGTH_LONG).show();
                return;
            }
            blockOn=!blockOn;
            NotificationBlockerService.blocking=blockOn;
            notif.setText(blockOn ? "🔕  BLOKIR NOTIFIKASI  •  ON" : "🔕  BLOKIR NOTIFIKASI  •  OFF");
        });
        root.addView(notif);

        Button clean=button("🧹  PEMBERSIH CACHE SENDIRI");
        clean.setOnClickListener(v -> {
            long before=folderSize(getCacheDir());
            deleteContents(getCacheDir());
            long after=folderSize(getCacheDir());
            Toast.makeText(this,"Cache Boost Rey dibersihkan: "+Math.max(0,before-after)/1024+" KB",Toast.LENGTH_LONG).show();
        });
        root.addView(clean);

        TextView note=text("Catatan: tanpa root, Android tidak mengizinkan aplikasi memaksa FPS/GPU atau menghapus cache aplikasi lain. Boost Rey hanya memakai kemampuan yang diizinkan sistem.",12);
        note.setTextColor(Color.GRAY); root.addView(note);

        setContentView(root);
    }

    boolean isNotificationAccessGranted() {
        String enabled=android.provider.Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        return enabled!=null && enabled.contains(getPackageName());
    }

    void showCrosshair() {
        if(!Settings.canDrawOverlays(this)) {
            crossOn=false;
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:"+getPackageName())));
            Toast.makeText(this,"Izinkan 'tampil di atas aplikasi lain', lalu aktifkan Crosshair.",Toast.LENGTH_LONG).show();
            return;
        }
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        crosshair=text("+",42); crosshair.setTextColor(green); crosshair.setGravity(Gravity.CENTER);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(120,120,
            Build.VERSION.SDK_INT>=26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.CENTER;
        wm.addView(crosshair,p);
    }

    void hideCrosshair() {
        if(wm!=null && crosshair!=null) {
            try { wm.removeView(crosshair); } catch(Exception ignored) {}
            crosshair=null;
        }
    }

    long folderSize(java.io.File f) {
        if(f==null || !f.exists()) return 0;
        if(f.isFile()) return f.length();
        long n=0; java.io.File[] fs=f.listFiles();
        if(fs!=null) for(java.io.File x:fs) n+=folderSize(x);
        return n;
    }

    void deleteContents(java.io.File f) {
        java.io.File[] fs=f.listFiles();
        if(fs!=null) for(java.io.File x:fs) {
            if(x.isDirectory()) { deleteContents(x); x.delete(); }
            else x.delete();
        }
    }

    @Override protected void onDestroy() {
        hideCrosshair();
        super.onDestroy();
    }
}
